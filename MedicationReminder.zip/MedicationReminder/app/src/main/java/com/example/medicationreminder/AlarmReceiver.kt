package com.example.medicationreminder

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.RingtoneManager
import android.os.Build
import androidx.core.app.NotificationCompat

class AlarmReceiver : BroadcastReceiver() {

    override fun onReceive(
        context: Context,
        intent: Intent
    ) {

        val medicine =
            intent.getStringExtra(
                "MEDICINE_NAME"
            ) ?: "Medicine"

        val channelId = "medicine_channel"

        val manager =
            context.getSystemService(
                NotificationManager::class.java
            )

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {

            val channel = NotificationChannel(
                channelId,
                "Medicine Reminder",
                NotificationManager.IMPORTANCE_HIGH
            )

            channel.enableVibration(true)

            manager.createNotificationChannel(
                channel
            )
        }

        val builder =
            NotificationCompat.Builder(
                context,
                channelId
            )
                .setSmallIcon(
                    android.R.drawable.ic_dialog_info
                )
                .setContentTitle(
                    "Medication Reminder"
                )
                .setContentText(
                    "Time to take $medicine!"
                )
                .setPriority(
                    NotificationCompat.PRIORITY_MAX
                )
                .setDefaults(
                    NotificationCompat.DEFAULT_ALL
                )
                .setAutoCancel(true)

        manager.notify(
            System.currentTimeMillis().toInt(),
            builder.build()
        )

        val sound =
            RingtoneManager.getDefaultUri(
                RingtoneManager.TYPE_ALARM
            )

        val ringtone =
            RingtoneManager.getRingtone(
                context,
                sound
            )

        ringtone.play()
    }
}