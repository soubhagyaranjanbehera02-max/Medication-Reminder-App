package com.example.medicationreminder

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TimePicker
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.util.Calendar

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_main)

        val button =
            findViewById<Button>(
                R.id.saveButton
            )

        val medicineBox =
            findViewById<EditText>(
                R.id.medicine
            )

        val timePicker =
            findViewById<TimePicker>(
                R.id.timePicker
            )

        button.setOnClickListener {

            val medicine =
                medicineBox.text.toString()

            val hour =
                timePicker.hour

            val minute =
                timePicker.minute

            val intent = Intent(
                this,
                AlarmReceiver::class.java
            )

            intent.putExtra(
                "MEDICINE_NAME",
                medicine
            )

            val pendingIntent =
                PendingIntent.getBroadcast(
                    this,
                    0,
                    intent,
                    PendingIntent.FLAG_IMMUTABLE
                )

            val alarmManager =
                getSystemService(
                    ALARM_SERVICE
                ) as AlarmManager

            val calendar =
                Calendar.getInstance()

            calendar.set(
                Calendar.HOUR_OF_DAY,
                hour
            )

            calendar.set(
                Calendar.MINUTE,
                minute
            )

            calendar.set(
                Calendar.SECOND,
                0
            )

            if (
                calendar.timeInMillis <
                System.currentTimeMillis()
            ) {

                calendar.add(
                    Calendar.DAY_OF_MONTH,
                    1
                )
            }

            val time =
                calendar.timeInMillis

            alarmManager.set(
                AlarmManager.RTC_WAKEUP,
                time,
                pendingIntent
            )

            Toast.makeText(
                this,
                "Alarm set for $medicine",
                Toast.LENGTH_SHORT
            ).show()
        }
    }
}